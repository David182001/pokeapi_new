var pokemon = angular.module("pokemon",[]);
//controler creation
pokemon.controller("ListadoPokemon", function($scope,$http) {
	//listado de los pokemon
	$scope.Listado = [];
	$scope.conteo = 0;
	//ciclo para repetir 20 veces un pokemon
	for(var y=0;y<=20;y++){
		$scope.conteo = $scope.conteo + 1 
	
	$http({
		method:"POST",
		url:"http://www.pokeapi.co/api/v2/pokemon/"+$scope.conteo
		//exitoa la funcion en la consola
	}).then(function successcallback(objeto){
		$scope.Listado.push(objeto.data)
		console.log($scope.Listado)
      
		})
	}
});


pokemon.controller("Login", function($scope){
	//funcion Inicio de sesion
	$scope.nombre = "pokeMerrick"
	$scope.contrasena = "mon"
	


	$scope.Inicio =function(a,b){
		if (a == $scope.nombre && b == $scope.contrasena) {
			window.open("pages/pokedex.html","_parent") 
		} else {
					swal("Usuario incorrecto o contraseña incorrecto")
				}
		}




});